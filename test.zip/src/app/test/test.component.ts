import { Component, OnInit, Input } from '@angular/core';
import { AppService } from '../app.service';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.scss']
})
export class TestComponent implements OnInit {

    title = 'Skills17';
    
  /**********Start */
stars: number[] = [1, 2, 3, 4, 5];
  selectedValue: number;
  //count = 6;
  // @ViewChild('namebutton') namebutton: ElementRef;
  /**********Start */

  message:string="";

  likeCounter = 100;

  likeBtn: boolean=true;
  likedBtn: boolean=false;

  constructor(private appService:AppService) {
    this.appService.getMessage.subscribe(msg => this.message = msg);
   }

  ngOnInit(): void {
  }
countStar(star: number) {
    this.selectedValue = star;
    console.log('Value of star', star);
  }

  updateMessage(){
    this.appService.setMessage('This is updated msg from test component');
  }

  increaseLike(){
    this.likeCounter++;
  this.likeBtn = false;
  this.likedBtn = true;
  }

  decreaseLike(){
    this.likeCounter--;
    this.likedBtn = false;
    this.likeBtn = true;
  }
 

}
