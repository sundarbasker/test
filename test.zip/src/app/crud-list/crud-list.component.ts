import { Component, OnInit, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validator, Validators } from '@angular/forms';
import { ApiService } from '../api.service';
import { datamodel } from './model';
import * as XLSX from 'xlsx';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-crud-list',
  templateUrl: './crud-list.component.html',
  styleUrls: ['./crud-list.component.scss']
})
export class CrudListComponent implements OnInit {

  @ViewChild('closebutton') closebutton: { nativeElement: { click: () => void; }; };
  
employeeform1!: FormGroup;
fileName= 'ExcelSheet.xlsx';

 selectedFile: File | null = null;
 

 employeeform: FormGroup = new FormGroup({
    fullname: new FormControl(''),
    username: new FormControl(''),
    email: new FormControl(''),
    password: new FormControl(''),
    confirmPassword: new FormControl(''),
    acceptTerms: new FormControl(false),
  });
  submitted = false;

data:undefined|datamodel[];

  constructor(private formbuilder: FormBuilder, private api:ApiService,
    private http: HttpClient) { }

  ngOnInit(): void {
    this.employeeform = this.formbuilder.group({
      name: [
          '',
          [
            Validators.required,
            Validators.minLength(6),
            Validators.maxLength(20),
          ],
        ],
      email: ['', [Validators.required, Validators.email]],
      city:['', Validators.required],
      state:['', Validators.required],
      pincode:['', Validators.required],
      phonenumber:['', Validators.required]      
    })
    this.getemployee();
  }

    get f(): { [key: string]: AbstractControl } {
    return this.employeeform.controls;
  }


  addemployee(data:datamodel){

    this.submitted = true;
    if (this.employeeform.invalid) {
      return;
      }

    console.log(JSON.stringify(this.employeeform.value, null, 2));
    console.log(data);
    this.api.addemployee(data).subscribe((res=>{
    return;
    }))   
 this.closebutton.nativeElement.click();
  this.employeeform.reset();
     this.getemployee();
  }

  getemployee(){
    this.api.getemployee().subscribe(res=>{
      this.data = res;
    })
  }
  delete(id:number){
    console.log('del');
    this.api.deleteemployee(id).subscribe(()=>{
      this.data = this.data?.filter(data=>data.id !==id);
      console.log('Employee deleted successfully');
    })
    //this.api.deleteemployee(id).subscribe(() =>{})
  }

    exportexcel(): void
  {
    /* pass here the table id */
    let element = document.getElementById('excel-table');
    const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
 
    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
 
    /* save to file */  
    XLSX.writeFile(wb, this.fileName);
 
  }

   onFileChange(event: any) {
            this.selectedFile = event.target.files[0];
          }

uploadFile() {
            if (this.selectedFile) {
                const formData = new FormData();
                formData.append('file', this.selectedFile, this.selectedFile.name);
                this.http
                    .post('http://localhost:3000/', formData)
                    .subscribe((response) => {
                    console.log('File uploaded successfully', response);
                    });
            }
          }
}



