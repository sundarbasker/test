export interface datamodel{
    id:number;
    name:string;
    email:string;
    city:string;
    state:string;
    pincode:number;
    phonenumber:number;
}