import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { environment  } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmplistService {

  constructor(private http: HttpClient) { }

  getList():Observable<any>{
    return this.http.get(environment.employeesList)
    .pipe(
      map(result=>result)
    );
  }
}
