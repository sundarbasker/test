import { Component, OnInit } from '@angular/core';
import { AppService } from '../app.service';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.scss']
})
export class AboutComponent implements OnInit {
  message:string="";
  constructor(private appService:AppService) {
    this.appService.getMessage.subscribe(msg => this.message = msg);
   }

  ngOnInit(): void {
  }

}
