import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { datamodel } from '../crud-list/model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit {


  userArray: any [] = [];
private serviceUrl = 'https://jsonplaceholder.typicode.com/users';
  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.loadAllUser();
  }

  loadAllUser(){
    this.http.get("https://jsonplaceholder.typicode.com/users").subscribe((res: any)=>{
      this.userArray = res;
    //  console.log('TEst Data',res);
    })
  }

  onEdit(item: any){
  item.isEdit = true;
  }
  editClose(item: any){
item.isEdit = false;
  }

  updatePost(item: datamodel): Observable<datamodel>{
    return this.http.patch<datamodel>(`${this.serviceUrl}/${item.id}`, item);

  }

  validateForm(item: any){
if(item != ''){
  return false;
}else{
  return true;
}
  }

  

}
