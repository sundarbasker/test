import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ListComponent } from './list/list.component';
import { TestComponent } from './test/test.component';
import { FormArrayComponent } from './form-array/form-array.component';
import { CrudComponent } from './crud/crud/crud.component';
import { Crud1Component } from './crud1/crud1/crud1.component';
import { ItemListComponent } from './item/item-list/item-list.component';
import { CrudListComponent } from './crud-list/crud-list.component';
import { UpdateComponent } from './crud-list/update/update.component';
import { TableComponent } from './table/table.component';

const routes: Routes = [
  { path: 'home', component:HomeComponent},
  { path: 'about', component: AboutComponent},
  { path: 'list', component: ListComponent},
  { path: 'test', component: TestComponent},
  { path: 'formArray', component: FormArrayComponent},
  { path: 'crud', component: CrudComponent},
  { path: 'crud1', component: Crud1Component},
  { path: 'item', component: ItemListComponent},
  { path: 'crud-list', component: CrudListComponent},
  { path: 'update/:id', component :UpdateComponent},
  { path: 'table', component: TableComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
