// import { Component, OnInit } from '@angular/core';
// import { FormBuilder, FormArray, FormGroup, ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../api.service';
import { datamodel } from '../crud-list/model';


@Component({
  selector: 'app-form-array',
  templateUrl: './form-array.component.html',
  styleUrls: ['./form-array.component.scss']
})
export class FormArrayComponent implements OnInit {

  empForm: FormGroup;
  tableForm: FormGroup;

  myForm: FormGroup;

  myArrayForm: FormGroup;
  data:undefined|datamodel[];
  constructor(private fb: FormBuilder, private http: HttpClient, private api: ApiService) {}

  ngOnInit() {

        this.api.getemployee().subscribe(res=>{
      this.data = res;
      console.log('test',this.data[1].name)
    })
    
    this.myForm = this.fb.group({
      items: this.fb.array([this.createItem()])
    });

    this.myArrayForm = this.fb.group({
      arrayItems: this.fb.array([this.createArrayItems()])
    });

    this.tableForm = this.fb.group({
      rows: this.fb.array([this.createRow()])
    });
    
  // form: FormGroup;
  // constructor(private fb: FormBuilder) {
  //   this.form = this.fb.group({
  //     items: this.fb.array([this.fb.control('')])
  // });
  //  }
  //  get items() {
  //   return this.form.get('items') as FormArray;
// }

// addItem() {
//     this.items.push(this.fb.control(''));
// }

// removeItem(index: number) {
//     this.items.removeAt(index);
// }

//   ngOnInit(): void {
//   }

  }
get arrayItems(): FormArray{
  return this. myArrayForm.get('arrayItems') as FormArray;
}

createArrayItems(){
  return this.fb.group({
    name: ['', Validators.required],
    id: ['', Validators.required]
  })
}

addArrayItem(){
  this.arrayItems.push(this.createArrayItems());
}

removeArrayItem(index: number){
  this.arrayItems.removeAt(index);
}
  get items(): FormArray {
    return this.myForm.get('items') as FormArray;
  }

  createItem(): FormGroup {
    return this.fb.group({
      employee_name: ['', Validators.required],
      quantity: ['', Validators.required]
    });
  }

  addItem() {
    this.items.push(this.createItem());
  }

  removeItem(index: number) {
    this.items.removeAt(index);
  }

  onSubmit() {
    if (this.myForm.valid) {
      const payload = this.myForm.value;
      this.http.post('https://dummy.restapiexample.com/api/v1/create', payload).subscribe(
        response => {
          console.log('Data saved', response);
        },
        error => {
          console.error('Error saving data', error);
        }
      );
    }
    
  }

  createRow(): FormGroup{
return this.fb.group({
  name: ['', Validators.required],
  email: ['', Validators.required, Validators.email]
});
  }

  get rows(): FormArray {
    return this.tableForm.get('rows') as FormArray;
  }
deleteBtn: boolean = true;

  addRow(): void{
     if(this.rows.length>=1){
      this.deleteBtn = false;
    }
    else{

      this.deleteBtn = true;
    }
    this.rows.push(this.createRow());
  }



  deleteRow(index:number): void{  
    const rows = this.tableForm.get('rows') as FormArray

     if(rows.length > 1){
      rows.removeAt(index)
    }
    else {
      rows.reset()
    }
    //this.rows.removeAt(index);
  }

  getemployee(){
    this.api.getemployee().subscribe(res=>{
      this.data = res;
    })
  }
  
   
}
