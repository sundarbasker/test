export interface User {
    isSelected : false;
    name: string;
    username: string;
    phone: number;
    website: string;
}