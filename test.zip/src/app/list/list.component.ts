import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmplistService } from '../emplist.service';
import { HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {

  constructor(private data:EmplistService, private router: Router) { }

  employeeslist: any;
  
  ngOnInit(): void {

    this.data.getList().subscribe(data=>{
      this.employeeslist = data;
      console.log('List data',this.data)
    })
  }

}
