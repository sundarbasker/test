import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'test';
  
  angForm :  FormGroup;
  constructor(private fb: FormBuilder) {
   this.createForm();
 }
 createForm() {
  this.angForm = this.fb.group({
     name: ['', Validators.required ]
  });
}
}
