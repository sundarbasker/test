import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-crud1',
  templateUrl: './crud1.component.html',
  styleUrls: ['./crud1.component.scss']
})
export class Crud1Component implements OnInit {

  dataForm: FormGroup;
  dataList: any[] = [];
  selectedData: any;
  isEditMode = false;

 constructor(private fb: FormBuilder, private apiService: ApiService) {
                this.dataForm = this.fb.group({
                    id: [''],
                    name: ['', Validators.required],
                    description: ['']
                });
            }
        
        
        ngOnInit(): void {
            this.loadData();
        }
        loadData() {
          this.apiService.readData().subscribe(data => {
              this.dataList = data;
          });
      }
      
      onSubmit() {
          if (this.dataForm.valid) {
              if (this.isEditMode) {
                  this.apiService.updateData(this.dataForm.value.id, this.dataForm.value).subscribe(() => {
                      this.loadData();  
                      this.resetForm();
                  });
              } else {
                  this.apiService.createData(this.dataForm.value).subscribe(() => {
                      this.loadData();
                      this.resetForm();
                  });
              }
          }
      }
      
      editData(data: any) {
          this.selectedData = data;
          this.isEditMode = true;
          this.dataForm.patchValue(data);
      }
     
      deleteData(id: number) {
          this.apiService.deleteData(id).subscribe(() => {
              this.loadData();
          });
      }
      
      resetForm() {
          this.dataForm.reset();
          this.isEditMode = false;
          this.selectedData = null;
      }

}
