import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private apiUrl = 'https://api.restful-api.dev/objects'; // Replace with your actual API endpoint
        
  constructor(private http: HttpClient) { }

  createData(data: any): Observable<any> {
      return this.http.post(this.apiUrl, data);
  }

  readData(): Observable<any[]> {
      return this.http.get<any[]>(this.apiUrl);
  }

  updateData(id: number, data: any): Observable<any> {
      return this.http.put(`${this.apiUrl}/${id}`, data);
  }

  deleteData(id: number): Observable<any> {
      return this.http.delete(`${this.apiUrl}/${id}`);
  }
}
