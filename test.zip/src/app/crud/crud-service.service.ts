 // service to interact with the API
 import { Injectable } from '@angular/core';
 import { HttpClient } from '@angular/common/http';
 import { Observable } from 'rxjs';
 import { FormGroup } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class CrudServiceService {
  private apiUrl = 'https://jsonplaceholder.typicode.com/posts';
 

  constructor(private http: HttpClient) { }

  
  // Create (POST)
  createData(data: any): Observable<any> {
    return this.http.post(this.apiUrl, data);
    }
   
  
    // Read (GET) all
    getData(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
    }
   
  
    // Read (GET) one by ID
    getDataById(id: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${id}`);
    }
   
  
    // Update (PUT)
    updateData(id: number, data:any): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, data);
    }
   
  
    // Delete (DELETE)
    deleteData(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
    }

}
