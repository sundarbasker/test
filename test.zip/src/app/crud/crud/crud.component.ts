import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CrudServiceService } from '../crud-service.service';
import { ItemService } from 'src/app/item.service';

@Component({
  selector: 'app-crud',
  templateUrl: './crud.component.html',
  styleUrls: ['./crud.component.scss']
})
export class CrudComponent implements OnInit {
  items: any[] = [];
  editables:any;

  constructor(private itemService: ItemService) { }

  ngOnInit(): void {
    this.getItems();
  }

  getItems() {
    this.itemService.getItems().subscribe(data => {
      this.items = data;
    });
  }

 createItem(name: string) {
    this.itemService.createItem({ name }).subscribe(() => {
       this.getItems();
    });
 }

edit(item:any) {  
  //this.itemService.updateItem(this.items.id, this.items)
  this.editables[item.name] = true;
}

  updateItem(id:number, items: any) {
    this.itemService.updateItem(id, this.items).subscribe({
      next: (response) => {
        console.log('Update successful', response);
      },
      error: (error) => {
        console.error('Update error', error);
      },
    });  
    
  }

  deleteItem(id: number) {
    this.itemService.deleteItem(id).subscribe(() => {
       this.getItems();
    });
  }
  
  // dataForm: FormGroup;
  // dataList: any[] = [];
 

  // constructor(private fb: FormBuilder, private dataService: CrudServiceService) {
  // this.dataForm = this.fb.group({
  // id: [''],
  // name: ['', Validators.required],
  // description: ['']
  // });
  // }

  // ngOnInit(): void {
  //   this.loadData();
  // }
  // loadData() {
  //   this.dataService.getData().subscribe(data => {
  //   this.dataList = data;
  //   });
  //   }
   
  
  //   onSubmit() {
  //   if (this.dataForm.valid) {
  //   if (this.dataForm.get('id')?.value) {
  //   // Update
  //   this.dataService.updateData(this.dataForm.get('id')?.value, this.dataForm.value).subscribe(() => {
  //   this.loadData();
  //   this.resetForm();
  //   });
  //   } else {
  //   // Create
  //   this.dataService.createData(this.dataForm.value).subscribe(() => {
  //   this.loadData();
  //   this.resetForm();
  //   });
  //   }
  //   }
  //   }
   
  
  //   editData(item: any) {
  //   this.dataForm.patchValue(item);
  //   }
   
  
  //   deleteData(id: number) {
  //   this.dataService.deleteData(id).subscribe(() => {
  //   this.loadData();
  //   });
  //   }
   
  
  //   resetForm() {
  //   this.dataForm.reset();
  //   }
    
}
