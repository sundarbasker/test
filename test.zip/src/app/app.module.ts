import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ListComponent } from './list/list.component';
import { TestComponent } from './test/test.component';
import { FormArrayComponent } from './form-array/form-array.component';
import { CrudComponent } from './crud/crud/crud.component';
import { Crud1Component } from './crud1/crud1/crud1.component';
import { ItemListComponent } from './item/item-list/item-list.component';
import { ItemCreateComponent } from './item/item-create/item-create.component';
import { ItemEditComponent } from './item/item-edit/item-edit.component';
import { CrudListComponent } from './crud-list/crud-list.component';
import { UpdateComponent } from './crud-list/update/update.component';
import { StarRatingComponent } from './star-rating/star-rating.component';
import { TableComponent } from './table/table.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ListComponent,
    TestComponent,
    FormArrayComponent,
    CrudComponent,
    Crud1Component,
    ItemListComponent,
    ItemCreateComponent,
    ItemEditComponent,
    CrudListComponent,
    UpdateComponent,
    StarRatingComponent,
    TableComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
