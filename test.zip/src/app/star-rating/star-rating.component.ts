import { Component, OnInit,  ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-star-rating',
  templateUrl: './star-rating.component.html',
  styleUrls: ['./star-rating.component.scss']
})
export class StarRatingComponent implements OnInit {
 
stars: number[] = [0, 1, 2, 3, 4, 5, 6];
  selectedValue: number;
  //count = 6;
  // @ViewChild('namebutton') namebutton: ElementRef;
  constructor() {}

  ngOnInit() {}

  countStar(star: number) {
    this.selectedValue = star;
    console.log('Value of star', star);
  }

  clearStar() {
    alert('select');
    // this.namebutton.nativeElement.classList.remove('selected');
  }

}
