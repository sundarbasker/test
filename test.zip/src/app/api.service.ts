import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { datamodel } from './crud-list/model';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

 constructor(private http: HttpClient) { }
   //add employee
  addemployee(data:datamodel){
  return this.http.post<datamodel>("http://localhost:3000/items", data)
  }
  //get employee
  getemployee(){
    return this.http.get<datamodel[]>("http://localhost:3000/items");
  }

    //delete employee
  deleteemployee(id:number){
    return this.http.delete<datamodel[]>("http://localhost:3000/items/"+id);
  }

  //fetch data employee
  fetchdata(id:number){
  return this.http.get<datamodel>("http://localhost:3000/items/"+id);
  }

  //update
  updateemployee(data:datamodel, id:number){
    return this.http.put<datamodel>("http://localhost:3000/items/"+id,data);
 
  }


}
