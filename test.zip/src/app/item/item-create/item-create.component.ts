import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ItemService } from '../item.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-item-create',
  templateUrl: './item-create.component.html',
  styleUrls: ['./item-create.component.scss']
})
export class ItemCreateComponent implements OnInit {
  itemForm: FormGroup;

  constructor(private fb: FormBuilder, private itemService: ItemService, private router: Router) {
    this.itemForm = this.fb.group({
      name: ['', Validators.required],
      description: ['']
    });
  }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  onSubmit() {
    this.itemService.createItem(this.itemForm.value).subscribe(() => {
      this.router.navigate(['/']);
    });
  }

}
