import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
    import { ItemService } from '../item.service';
    import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-item-edit',
  templateUrl: './item-edit.component.html',
  styleUrls: ['./item-edit.component.scss']
})
export class ItemEditComponent implements OnInit {

  itemForm: FormGroup;
      itemId: number | null = null;

      constructor(
        private fb: FormBuilder,
        private itemService: ItemService,
        private route: ActivatedRoute,
        private router: Router
      ) {
        this.itemForm = this.fb.group({
          name: ['', Validators.required],
          description: ['']
        });
      }

      ngOnInit(): void {
        this.itemId = Number(this.route.snapshot.paramMap.get('id'));
        if (this.itemId) {
          this.itemService.getItem(this.itemId).subscribe(item => {
            this.itemForm.patchValue(item);
          });
        }
      }

      onSubmit() {
         if (this.itemId !== null) {
          this.itemService.updateItem(this.itemId, this.itemForm.value).subscribe(() => {
            this.router.navigate(['/']);
          });
         }
      }

}
