import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { datamodel } from './crud-list/model';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  private message = new BehaviorSubject('Initial message');
  getMessage = this.message.asObservable();

  constructor(private http: HttpClient) { }


  setMessage(message: string){
    this.message.next(message)
  }
}
